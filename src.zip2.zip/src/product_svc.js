const express = require('express')
var mysql = require('mysql')
var cors = require('cors')

const app = express()
const port = 7799

// body parser config
app.use(express.urlencoded({extended:false}))
app.use(express.json())

// add the required cors headers in the response
app.use(cors())

//sql conection 
var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'brando',
    port:3306 //default port
  })  
  connection.connect()

//Fetch data from data base and display on UI
  app.get('/product', (req, res) => {
    var qry_select="select * from list_all_products"
    connection.query(qry_select, function (err, rows, fields) {
      if (err) throw err

      res.send(rows)
      console.log(rows.length +"Product fetch from the database")
    })
  })

  
  app.get('/', (req, res) => {
    res.send('Welcome to Brando e-commerce Application Service!')
  })
  
  app.listen(port, () => {
    console.log(`Brando app listening at http://localhost:${port}`)
  })

//js 
function ValidateEmail(inputText)
{
  var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  if(inputText.value.match(mailformat))
  {
    alert("Valid email address!");
    document.form1.text1.focus();
    return true;
  }
  else
  {
    alert("You have entered an invalid email address!");
    document.form1.text1.focus();
    return false;
  }
}
  
