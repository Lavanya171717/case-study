import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/product';


@Component({
  selector: 'app-item-list',
  templateUrl: './item-list.component.html',
  styleUrls: ['./item-list.component.css']
})
export class ItemListComponent implements OnInit {

  items!:Product[]

  constructor() {

    // this.items=[
    //   {itemId:1,nameOfproduct:"bags",description:'hjshjf jhsjhsjf hfjhj jd',price:199,img:'../assets/img/shoes.png'},
    //   {itemId:2,nameOfproduct:"t-shirt",description:'hjshjf jhsjhsjf hfjhj jd',price:250,img:'../assets/img/bags.png'},
    //   {itemId:3,nameOfproduct:"shoes",description:'hjshjf jhsjhsjf hfjhj jd',price:2999,img:'../assets/img/t-shirts.png'},
    //   {itemId:4,nameOfproduct:"all products",description:'hjshjf jhsjhsjf hfjhj jd',price:1966,img:'../assets/img/shoes.png'},
    //   {itemId:5,nameOfproduct:"logo",description:'hjshjf jhsjhsjf hfjhj jd',price:399,img:'../assets/img/shoes.png'},
    //   {itemId:6,nameOfproduct:"logo",description:'hjshjf jhsjhsjf hfjhj jd',price:399,img:'../assets/img/allProduct.jpg'}
    // ]
   }

  ngOnInit(): void {

    
  }

}
