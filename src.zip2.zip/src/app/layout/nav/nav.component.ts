import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {

  userDisplayName: any

  constructor() { 
    this.userDisplayName = ""
  }

  ngOnInit(): void {
    this.userDisplayName = sessionStorage.getItem('loggedUser');
    console.log(this.userDisplayName)
  }

}
