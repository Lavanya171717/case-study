import { HttpClient } from '@angular/common/http';

import { Injectable } from '@angular/core';

import { BehaviorSubject, Observable } from 'rxjs';



@Injectable({

  providedIn: 'root'

})

export class ApiService {
  public mycartItemList : any=[]
  public meals = new BehaviorSubject<any>([]);
  public sweets = new BehaviorSubject<any>([]);
  
  constructor(private http:HttpClient) { }
  
  apiUrl='https://localhost:44367/api/t-shirts';

  apiUrl1='https://localhost:44367/api/bags';

  apiUrl2='https://localhost:44367/api/shoes';
  
  getAllMealspackData():Observable<any> {
    return this.http.get(`${this.apiUrl}`);
  }

  getAllSweetsData():Observable<any> {
    return this.http.get(`${this.apiUrl1}`);
  }

  getAllSavoriesData():Observable<any> {
    return this.http.get(`${this.apiUrl2}`);
  }
}