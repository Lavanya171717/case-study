import { Component, OnInit } from '@angular/core';
import { CartService } from '../services/cart.service';
import { Cart } from '../cart.model';
import { Product } from '../product';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  public products:any=[];
  public grandTotal : number[]=[];
  cartitems:Product[]=[];
  public grandTotal1 : number=0;

  constructor(private cartService:CartService) { }

  ngOnInit(): void {
    this.cartService.getItem().subscribe(
      response => {
        this.cartitems = response
      }, error => {
        console.log(error)
      }

    )
    
    
  }
  removeItem(prod:any){
    this.cartService.deleteCartItem(prod).subscribe(
      response =>{

        alert("1 item is deleted")

      },error =>{

          console.log(error)

      }
    )
  }
 
  }

