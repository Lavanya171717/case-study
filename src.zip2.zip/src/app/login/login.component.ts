import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CartService } from '../services/cart.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  email:string

  constructor(private router:Router,private httpsvc:CartService) { 
    this.email = ""

  }

  ngOnInit(): void {
  }
  CheckingUser(userEmail:string, password:string){

    this.httpsvc.checkUser(userEmail,password).subscribe(
      
      response =>{
        this.email = userEmail

        alert("You have been logged in Succesfully!!")

        sessionStorage.setItem('loggedUser', this.email);
        this.router.navigate(["/"])

      }, error =>{

        console.log(error)

        alert("Invalid user. Please enter valid details or sign up.")

      }

    )

  }

}
