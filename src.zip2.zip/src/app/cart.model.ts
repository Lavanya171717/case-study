export class Cart
{
    
    public price :number;
    public Name:string;
    public description:any;
    public quantity:any;
    public picture:string;
    public total:any;  

    constructor(price :number,Name:string,description:any,quantity:any,total:any,picture:string){
        this.price=price;
        this.Name=Name;
        this.description=description;
        this.quantity=quantity;
        this.total=total;
        this.picture=picture
    }
}


