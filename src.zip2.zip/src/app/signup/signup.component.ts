import { Component, OnInit } from '@angular/core';
import { EmailValidator } from '@angular/forms';
import { Router } from '@angular/router';
import { Login } from '../login';
import { Product } from '../product';
import { CartService } from '../services/cart.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  errorMessage1:string
  errorMessage2:string
  errorMessage3:string
  errorMessage4:string
  errorMessage5:string
  errorMessage6:string



  constructor(private httpsvc:CartService, private router:Router) { 
    this.errorMessage1 = ""
    this.errorMessage2 = ""
    this.errorMessage3 = ""
    this.errorMessage4 = ""
    this.errorMessage5 = ""
    this.errorMessage6 = ""

   
  }

  ngOnInit(): void {
  }

  registerUser(newUser:Login){

    if (newUser.firstName.length<1 || newUser.lastName.length<1 || newUser.emailId.length<1 || newUser.password.length<1 || newUser.mobile<1 || newUser.address.length<1){
      if (newUser.firstName.length<1){
        this.errorMessage1 = "*First Name is required"
      }
      else {
        this.errorMessage1 = ""
      }
      if (newUser.lastName.length<1){
        this.errorMessage2 = "*Last Name is required"
      }
      else {
        this.errorMessage2 = ""
      }
      if (newUser.emailId.length<1){
        this.errorMessage3 = "*Email Id is required"
      }
      else {
        this.errorMessage3 = ""
      }
      if (newUser.password.length<1){
        this.errorMessage4 = "*Password is required"
      }
      else {
        this.errorMessage4 = ""
      }
      if (newUser.mobile<1){
        this.errorMessage5 = "*Mobile Number is required"
      }
      else {
        this.errorMessage5 = ""
      }
      if (newUser.address.length<1){
        this.errorMessage6 = "*Address is required"
      }
      else {
        this.errorMessage6 = ""
      }
    }

    else{
      this.httpsvc.addUser(newUser).subscribe( 

        response =>{ 
 
           alert("You have registered successfully")
           this.router.navigate(["/login"]) 
 
       }, error =>{     
 
        alert("The Email Id is already in use") 
 
          }
 
       )}
      
    }

    /* ValidateEmail(inputText : EmailValidator )
    {
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if(inputText.value.match(mailformat))
    {
      alert("Valid email address!");
      document.form1.text1.focus();
      return true;
    }
    else
    {
      alert("You have entered an invalid email address!");
      document.form1.text1.focus();
      return false;
    }
  }*/

    
}
