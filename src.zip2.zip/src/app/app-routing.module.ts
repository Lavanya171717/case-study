import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CartComponent } from './cart/cart.component';
import { BagsComponent } from './component/category/bags/bags.component';
import { ShoesComponent } from './component/category/shoes/shoes.component';
import { TShirtsComponent } from './component/category/t-shirts/t-shirts.component';
import { ItemListComponent } from 'src/app/home/item-list/item-list.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';


const routes: Routes = [
  {path:"", component:ItemListComponent},
  {path:"t-shirts", component:TShirtsComponent},
  {path:"bags", component:BagsComponent},
  {path:"shoes", component:ShoesComponent},
  {path:"cart", component:CartComponent},
  {path:"signup", component:SignupComponent},
  {path:"login", component:LoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
