import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { HeaderComponent } from 'src/app/layout/header/header.component';
import { FooterComponent } from 'src/app/layout/footer/footer.component';
import { NavComponent } from 'src/app/layout/nav/nav.component';
import { HomeComponent } from 'src/app/home/home.component';
import { ItemListComponent } from 'src/app/home/item-list/item-list.component';
import { ItemComponent } from 'src/app/home/item-list/item/item.component';
import { TShirtsComponent } from './component/category/t-shirts/t-shirts.component';
import { BagsComponent } from 'src/app/component/category/bags/bags.component';
import { ShoesComponent } from './component/category/shoes/shoes.component';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { CartComponent } from './cart/cart.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';



@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    NavComponent,
    HomeComponent,
    ItemComponent,
    ItemListComponent,
    TShirtsComponent,
    BagsComponent,
    ShoesComponent,
    CartComponent,
    LoginComponent,
    SignupComponent,
    
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    AppRoutingModule,
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
