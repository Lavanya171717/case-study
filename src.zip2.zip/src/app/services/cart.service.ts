import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { ApiService } from '../api.service';
import { Login } from '../login';
import { Product } from '../product';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  serverUrl = "https://localhost:44367/api"

  public cartItemList : any=[]
  public productList = new BehaviorSubject<any>([]);
  public bags = new BehaviorSubject<any>([]);
  public shoes = new BehaviorSubject<any>([]);
  public tshirts = new BehaviorSubject<any>([]);
  public search = new BehaviorSubject<string>("");
  price: any;

  constructor(private ser:ApiService, private httpsvc:HttpClient) { }
  getProducts(){
    return this.productList.asObservable();
  }
  setProduct(product : any){
    this.cartItemList.push(...product);
    this.productList.next(product);
  } 
  addtoCart(product: any) {
    var count = 0;
      this.cartItemList.map((a: any, index: any) => {
        if (product._price === a._price) {
          a.quantity=parseInt(a.quantity) +1; 
          a.total = parseInt(a.quantity) * parseFloat(a.price);
          count = 1;
        }        
      })
      if (count == 0) {
        this.cartItemList.push(product);
        this.productList.next(this.cartItemList);
        this.getTotalPrice();
      }
  }
  
 getTotalPrice():number{ 

  let grandTotal=0;
  
this.cartItemList.forEach((a:any)=>{
grandTotal += parseFloat(a.total)
});
return grandTotal;

}
removeCartItem(product: any) {
  var result = confirm(`Are you sure?`);
  if (result) {
  this.cartItemList.map((a: any, index: any) => {
    if (product._price === a._price && product.quantity && parseInt(product.quantity) > 0) {
      a.quantity = parseInt(a.quantity) - 1;
      a.total = parseInt(a.quantity) * parseFloat(a.price);
      if (parseInt(a.quantity) == 0) {
        this.cartItemList.splice(index, 1)
      }
    }
    else {
      if (product._price === a._price) {
        this.cartItemList.splice(index, 1)
      }
    }
  })
  this.productList.next(this.cartItemList);
}
}

deleteCartItem(name:string):Observable<string>{

  return this.httpsvc.delete<string>(this.serverUrl+"/AddToCarts/" + name)

}

  displayBasket():Observable<Product[]>{
    return this.httpsvc.get<Product[]>(this.serverUrl + "/bags")
  }

  displayshoeBasket():Observable<Product[]>{
    return this.httpsvc.get<Product[]>(this.serverUrl + "/shoes")
  }

  displaytshirtBasket():Observable<Product[]>{
    return this.httpsvc.get<Product[]>(this.serverUrl + "/tshirts")
  }

  mycart(product:Product):Observable<Product>{
    var prd = {
      name:product.name, description:product.description, price:product.price, img:product.img, quantity:product.quantity, total:product.total
    }
    const reqopts = {
      headers:new HttpHeaders({
        "content-Type":"application/json"
      })
    }
    return this.httpsvc.post<Product>(this.serverUrl + "/AddToCarts",prd,reqopts)
  }

  getItem():Observable<Product[]>{
    return this.httpsvc.get<Product[]>(this.serverUrl + "/AddToCarts")
  }

  // for login

  addUser(newUser:Login):Observable<Login>{

    var user = {

        FirstName:newUser.firstName,

        LastName:newUser.lastName,

        EmailId:newUser.emailId,

        Password:newUser.password,

        Mobile:newUser.mobile,

        Address:newUser.address

      }

    const reqopts={

      headers:new HttpHeaders({"content-Type":"application/json"})

    }

    return this.httpsvc.post<Login>(this.serverUrl+"/Logins",user,reqopts)

  }

  checkUser( username:string,password:string):Observable<string>{

   

    return this.httpsvc.get<string>(this.serverUrl+"/Logins/" + username +"/"+password)

  }
 
}


