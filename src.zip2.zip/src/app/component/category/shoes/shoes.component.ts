import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/product';
import { CartService } from 'src/app/services/cart.service';

@Component({
  selector: 'app-shoes',
  templateUrl: './shoes.component.html',
  styleUrls: ['./shoes.component.css']
})
export class ShoesComponent implements OnInit {
  public data:any;
  searchkey:string="";
  shoeBasket:Product[];
  

 //we have fetch the functions from the service(cart service) we have created 
  constructor(private cartService:CartService) {
    this.shoeBasket = []
    
   }
    ngOnInit(): void {
      this.cartService.search.subscribe((val:any)=>{
        this.searchkey = val;
      })

      this.cartService.displayshoeBasket().subscribe(
        response => {
          this.shoeBasket = response
          console.log(this.shoeBasket)
        }, error =>{
          console.log(error)
        }
        )
   
    
  }
    //this function is taken from the cart service 
      addtocart(prod:any){
        Object.assign(prod,{quantity:1,total:prod.price})
      this.cartService.addtoCart(prod);
    }

    addItemOnCart(pro:Product){
      this.cartService.mycart(pro).subscribe(
        response => {
          alert("Successfully added to cart")
        }, error => {
          console.log(error)
        }
      )
    }
    
  }

  
