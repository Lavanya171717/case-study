import { analyzeAndValidateNgModules } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/product';
import { CartService } from 'src/app/services/cart.service';


@Component({
  selector: 'app-bags',
  templateUrl: './bags.component.html',
  styleUrls: ['./bags.component.css']
})
export class BagsComponent implements OnInit {
  public data:any;
  searchkey:string="";
  bagBasket:Product[];

 //we have fetch the functions from the service(cart service) we have created 
  constructor(private cartService:CartService) {
    this.bagBasket = []    
   }
    ngOnInit(): void {
      this.cartService.search.subscribe((val:any)=>{
        this.searchkey = val;
      })

      this.cartService.displayBasket().subscribe(
        response => {
          this.bagBasket = response
          console.log(this.bagBasket)
        }, error =>{
          console.log(error)
        }
        )
   
    
  }
    //this function is taken from the cart service 
      addtocart(prod:any){
        Object.assign(prod,{quantity:1,total:prod.price})
      this.cartService.addtoCart(prod);
    }

    addItemOnCart(pro:Product){
      this.cartService.mycart(pro).subscribe(
        response => {
          alert("Successfully added to cart")
        }, error => {
          console.log(error)
        }
      )
    }
    
    
  }






