import { Component, OnInit } from '@angular/core';
import { provideRoutes } from '@angular/router';
import { ApiService } from 'src/app/api.service';
import { Product } from 'src/app/product';
import { CartService } from 'src/app/services/cart.service';

@Component({
  selector: 'app-t-shirts',
  templateUrl: './t-shirts.component.html',
  styleUrls: ['./t-shirts.component.css']
})
export class TShirtsComponent implements OnInit {
  public data:any;
  searchkey:string="";
  tshirtBasket:Product[];

 //we have fetch the functions from the service(cart service) we have created 
  constructor(private cartService: CartService) {
    this.tshirtBasket = []
    
    
   }
    ngOnInit(): void {
      this.cartService.search.subscribe((val:any)=>{
        this.searchkey = val;
      })

      this.cartService.displaytshirtBasket().subscribe(
        response => {
          this.tshirtBasket = response
          console.log(this.tshirtBasket)
        }, error =>{
          console.log(error)
        }
        )
   
    
  }
    //this function is taken from the cart service 
      addtocart(prod:any){
        Object.assign(prod,{quantity:1,total:prod.price})
      this.cartService.addtoCart(prod);
    }

    addItemOnCart(pro:Product){
      this.cartService.mycart(pro).subscribe(
        response => {
          alert("Successfully added to cart")
        }, error => {
          console.log(error)
        }
      )
    }
    
    
  }

